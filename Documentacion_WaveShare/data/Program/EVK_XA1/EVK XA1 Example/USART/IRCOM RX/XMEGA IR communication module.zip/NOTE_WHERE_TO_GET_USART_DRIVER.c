NOTE: Get the usart_driver.c and usart_driver.h from the AVR1307: Using the XMEGA USART
	